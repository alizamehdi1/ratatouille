## Epicurean Symphony" - Stay Hungry Eat Food

### About this prjoect:

This is a Epicurean Symphony restaurant site. With this you can browse through the food of your choice online.

### What user can do:

- User can browse throguh different cuisine food here without an account.
- Users can check out the different outlets/locations of the restaurant.
- Users can find about the upcoming events organized by restaurant.

### Languages & Tools:

#### react, react-router-dom, react-hook-form, react-bootstrap, material-ui, firebase, nodejs, mongodb

### Project Screenshot:

<img src="https://i.ibb.co/cNyJ09W/ehungry.png" alt="ehungry googlermridul" border="0">
